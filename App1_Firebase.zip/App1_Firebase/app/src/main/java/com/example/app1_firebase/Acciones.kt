package com.example.app1_firebase

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Acciones : AppCompatActivity() {

    private lateinit var btnVolverAcciones: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_acciones)

        btnVolverAcciones = findViewById(R.id.btnVolverAcciones)

        btnVolverAcciones.setOnClickListener {
            finish()
        }
    }
}