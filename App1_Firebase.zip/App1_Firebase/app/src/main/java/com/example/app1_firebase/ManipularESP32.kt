package com.example.app1_firebase

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ManipularESP32 : AppCompatActivity() {

    private lateinit var lblEstadoESP: TextView
    private lateinit var btnEncender: Button
    private lateinit var btnApagar: Button
    private lateinit var btnVolverESP: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manipular_esp32)

        lblEstadoESP = findViewById(R.id.lblEstadoESP)
        btnEncender = findViewById(R.id.btnEncender)
        btnApagar = findViewById(R.id.btnApagar)
        btnVolverESP = findViewById(R.id.btnVolverESP)

        val databaseRef = FirebaseDatabase.getInstance().getReference("dispositivo")

        databaseRef.child("estado").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val estado = snapshot.getValue(Int::class.java) ?: 0
                if (estado == 1) {
                    lblEstadoESP.text = "Estado: ¡Encendido (ON)!"
                } else {
                    lblEstadoESP.text = "Estado: Apagado (OFF)"
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Error al leer Firebase: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })

        btnEncender.setOnClickListener {
            databaseRef.child("estado").setValue(1)
                .addOnSuccessListener {
                    Toast.makeText(this, "Comando enviado: ON", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        btnApagar.setOnClickListener {
            databaseRef.child("estado").setValue(0)
                .addOnSuccessListener {
                    Toast.makeText(this, "Comando enviado: OFF", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        btnVolverESP.setOnClickListener {
            finish()
        }
    }
}