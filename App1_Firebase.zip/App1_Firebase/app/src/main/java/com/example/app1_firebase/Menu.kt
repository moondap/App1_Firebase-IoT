package com.example.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Menu : AppCompatActivity() {

    private lateinit var lblBienvenida: TextView
    private lateinit var btnPerfil: Button
    private lateinit var btnAcciones: Button
    private lateinit var btnManipular: Button
    private lateinit var btnCerrarSesion: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        lblBienvenida = findViewById(R.id.lblBienvenida)
        btnPerfil = findViewById(R.id.btnPerfil)
        btnAcciones = findViewById(R.id.btnAcciones)
        btnManipular = findViewById(R.id.btnManipular)
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)

        val usuario = intent.getSerializableExtra("usuario") as? Usuario

        if (usuario != null) {
            lblBienvenida.text = "Bienvenido, ${usuario.nombre}"
        }

        btnPerfil.setOnClickListener {
            val intent = Intent(this, Perfil::class.java)
            intent.putExtra("usuario", usuario) // Pasamos el usuario también al perfil si lo necesita
            startActivity(intent)
        }

        btnAcciones.setOnClickListener {
            val intent = Intent(this, Acciones::class.java)
            startActivity(intent)
        }

        btnManipular.setOnClickListener {
            val intent = Intent(this, ManipularESP32::class.java)
            startActivity(intent)
        }

        btnCerrarSesion.setOnClickListener {
            val intent = Intent(this, Principal::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}