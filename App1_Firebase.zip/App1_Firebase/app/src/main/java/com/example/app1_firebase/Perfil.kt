package com.example.app1_firebase

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Perfil : AppCompatActivity() {

    private lateinit var txtNombrePerfil: TextView
    private lateinit var txtEmailPerfil: TextView
    private lateinit var txtTipoPerfil: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        txtNombrePerfil = findViewById(R.id.txtNombrePerfil)
        txtEmailPerfil = findViewById(R.id.txtEmailPerfil)
        txtTipoPerfil = findViewById(R.id.txtTipoPerfil)

        val usuario = intent.getSerializableExtra("usuario") as? Usuario

        if (usuario != null) {
            txtNombrePerfil.text = "Nombre: ${usuario.nombre}"
            txtEmailPerfil.text = "Correo: ${usuario.email}"
            txtTipoPerfil.text = "Tipo de usuario: ${usuario.tipo}"
        }

        val btnVolverPerfil = findViewById<android.widget.Button>(R.id.btnVolverPerfil)
        btnVolverPerfil.setOnClickListener {
            finish()
        }
    }
}