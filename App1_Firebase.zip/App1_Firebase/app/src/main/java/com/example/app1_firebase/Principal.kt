package com.example.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Principal : AppCompatActivity() {

    private lateinit var txtEmail: EditText
    private lateinit var txtPassword: EditText
    private lateinit var btnIngresar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        txtEmail = findViewById(R.id.txtEmail)
        txtPassword = findViewById(R.id.txtPassword)
        btnIngresar = findViewById(R.id.btnIngresar)

        btnIngresar.setOnClickListener {
            val emailIngresado = txtEmail.text.toString().trim()
            val passIngresada = txtPassword.text.toString().trim()

            if (emailIngresado.isNotEmpty() && passIngresada.isNotEmpty()) {
                validarUsuarioFirebase(emailIngresado, passIngresada)
            } else {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validarUsuarioFirebase(email: String, pass: String) {
        val database = FirebaseDatabase.getInstance().getReference("usuarios")

        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var usuarioEncontrado: Usuario? = null

                for (childSnapshot in snapshot.children) {
                    val dbEmail = childSnapshot.child("email").getValue(String::class.java)

                    if (dbEmail == email) {
                        val dbNombre = childSnapshot.child("nombre").getValue(String::class.java) ?: ""
                        val dbTipo = childSnapshot.child("tipo").getValue(String::class.java) ?: ""

                        // Obtenemos la contraseña de forma segura (puede venir como Long o String)
                        val dbPassObj = childSnapshot.child("contraseña").value
                        val dbPassStr = dbPassObj?.toString() ?: ""

                        if (dbPassStr == pass) {
                            // Suponiendo que tu data class Usuario recibe (nombre, email, tipo, contraseña)
                            val passInt = dbPassStr.toIntOrNull() ?: 0
                            usuarioEncontrado = Usuario(dbNombre, dbEmail, dbTipo, passInt)
                        }
                        break
                    }
                }

                if (usuarioEncontrado != null) {
                    Toast.makeText(applicationContext, "Bienvenido ${usuarioEncontrado.nombre}", Toast.LENGTH_SHORT).show()

                    val intent = Intent(applicationContext, Menu::class.java)
                    intent.putExtra("usuario", usuarioEncontrado)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(applicationContext, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}