package com.example.app1_firebase

import java.io.Serializable

data class Usuario(
    val nombre: String,
    val email: String,
    val tipo: String,
    val contraseña: Int
) : Serializable